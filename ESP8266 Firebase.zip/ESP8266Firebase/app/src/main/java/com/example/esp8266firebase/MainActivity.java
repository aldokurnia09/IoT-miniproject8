package com.example.esp8266firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    DatabaseReference dref;

    String valueSound;
    String valueWater;
    int valueWater2;
    String valueLamp1;
    TextView txtSoundValue;
    TextView txtWaterValue;
    TextView txtLamp1Value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtSoundValue = (TextView) findViewById(R.id.txtSoundValue);
        txtWaterValue = (TextView) findViewById(R.id.txtWaterValue);
        txtLamp1Value = (TextView) findViewById(R.id.txtLamp1Value);

        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                valueSound = dataSnapshot.child("Node1/sound").getValue().toString();
                if(valueSound.equals("0")){
                    txtSoundValue.setText(": No Sound");
                }
                else if(valueSound.equals("1")){
                    txtSoundValue.setText(": Sound Detected");
                }

                valueWater = dataSnapshot.child("Node1/water").getValue().toString();
                valueWater2 =  Integer.parseInt(valueWater);
                if(valueWater2 >= 125){
                    txtWaterValue.setText(": Low Water");
                }
                if(valueWater2 >= 250){
                    txtWaterValue.setText(": Mid Water");
                }
                if(valueWater2 >= 375){
                    txtWaterValue.setText(": High Water");
                }
                if(valueWater2 >= 475){
                    txtWaterValue.setText(": Full Water");
                }
                if(valueWater2 < 125){
                    txtWaterValue.setText(": No Water");
                }

                valueLamp1 = dataSnapshot.child("Node1/lamp1").getValue().toString();
                if(valueLamp1.equals("0")){
                    txtLamp1Value.setPadding(15,0,15,0);
                    txtLamp1Value.setText("OFF");
                }
                else if(valueLamp1.equals("1")){
                    txtLamp1Value.setPadding(25,0,26,0);
                    txtLamp1Value.setText("ON");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
